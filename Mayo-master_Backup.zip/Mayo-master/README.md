# Mayo

Works with Xcode 7 and Swift 2
