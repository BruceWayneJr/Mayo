//
//  EventLogCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/20/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class EventLogCell: UITableViewCell {

    @IBOutlet weak var eventTypeLabel: UILabel!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var timeStampLabel: UILabel!
    @IBOutlet weak var logLabel: UILabel!
    
    private var log: EventLog!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        separatorInset = UIEdgeInsetsZero
        preservesSuperviewLayoutMargins = false
        layoutMargins = UIEdgeInsetsZero
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setLogData(log: EventLog) {
        self.log = log
                
        let t = Mayo.dateFormatter.stringFromDate(log.time)
        eventTypeLabel.text = log.type.uppercaseString
        timeStampLabel.text = t
        timerLabel.text = log.timerTime
        logLabel.text = log.log
        
        var textColor = UIColor.blackColor()
        var bColor = UIColor.whiteColor()
        
        if let backColor = log.color {
            bColor = backColor
            textColor = backColor.isLight() ? UIColor.blackColor() : UIColor.whiteColor()
        } else {
            bColor = UIColor.whiteColor()
            textColor = UIColor.blackColor()
        }
        
        backgroundColor = bColor
        eventTypeLabel.textColor = textColor
        timerLabel.textColor = textColor
        logLabel.textColor = textColor
        timeStampLabel.textColor = textColor
    }

}
