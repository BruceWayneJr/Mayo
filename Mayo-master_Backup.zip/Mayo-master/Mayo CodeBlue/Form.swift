//
//  Form.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/20/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Form: Decodable {
    var codes = [Code]()
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    required init() {
        
    }
    
    required init(data: JSON) {
        guard let codes = data["codes"] as? Array<JSON> else {
            // return error
            return
        }
        
        for c in codes {
            let codeData = Code(data: c)
            self.codes.append(codeData)
        }
    }
    
    func toJSON() -> JSON {
        return [ "codes" : codes.map { $0.toJSON() } ]
    }
}

extension Form: AdminRepresentationType {
    static var adminRows = [""]
    
    func admin_numberOfSections() -> Int {
        return 2
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        return sectionIndex == 0 ? codes.count : 1
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == 0 {
            let code = codes[indexPath.row]
            return .Standard(code.name == "" ? "No Code Name" : code.name, "Code", code.admin_representationState())
        } else {
            return .Standard("Add new Code", "", .Valid)
        }
        
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return sectionIndex == 0 ? "\(codes.count) codes(s)" : ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 0 {
            let code = codes[indexPath.row]
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(code)
            code.adminTableDelegate = pushVC
            return .Push(pushVC)
        } else {
            let newCode = Code()
            codes.append(newCode)
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(newCode)
            newCode.adminTableDelegate = pushVC
            return .Push(pushVC)
        }
    }
    
    func admin_moveableSections() -> [Int] {
        return [0]
    }
    
    func admin_movedData(from from: Int, to: Int) {
        let movedData = codes.removeAtIndex(from)
        codes.insert(movedData, atIndex: to)
    }
    
    func admin_deletedRow(rowIndex: Int) {
        if rowIndex >= 0 && rowIndex < codes.count {
            codes.removeAtIndex(rowIndex)
        }
    }
    
    func admin_representationState() -> RepresentationState {
        for c in codes {
            if c.admin_representationState() == .Invalid {
                return .Invalid
            }
        }
        
        return .Valid
    }
}
