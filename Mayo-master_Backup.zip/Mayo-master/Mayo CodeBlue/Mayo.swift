//
//  Mayo.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 6/25/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation

protocol CodeAlertDelegate {
    func newAlert(message: String)
}

class Mayo: NSObject {
    
    static let sharedInstance = Mayo()
    
    var eventLogs = [EventLog]()
    var alertLogs = [Int:EventLog]()
    
    var json = JSON()
    var code = Code()
    var form = Form()
    var selectedCodeIndex: Int = 0 {
        didSet {
            code = form.codes[selectedCodeIndex]
        }
    }
    
    private var codeTimer: NSTimer?
    
    private var time: Int = 0 {
        willSet {
            stringTime = String(format: "%02d:%02d", newValue/60, newValue%60)
        }
    }
    private var stringTime = "00:00"
    private var codeTimerTarget: AnyObject?
    private var codeTimerSelector: Selector?
    
    private var timerStarted = false
    
    var timerAlertDelegate: CodeAlertDelegate?
    
    static var dateFormatter: NSDateFormatter {
        let formatter = NSDateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter
    }
    
    private override init() {
        
    }
    
    static func newCode() {
        sharedInstance.resetAll()
        sharedInstance.readJSON()
        
        NSNotificationCenter.defaultCenter().postNotificationName("NewCode", object: nil)
    }
    
    func readJSON() {
        let json = File.getCurrentForms()
        
        self.json = json
        let form = Form(data: json)
        self.form = form
        
        if form.codes.count > 0 {
            self.code = form.codes.first!
        } else {
            self.code = Code()
        }
        
    }
    
    internal static func getStringTime() -> String {
        if !sharedInstance.timerStarted {
            NSNotificationCenter.defaultCenter().postNotificationName("ManualStart", object: nil)
        }
        
        return sharedInstance.stringTime
    }
    
    static func logEvent(var log: EventLog) {
        log.timerTime = getStringTime()
        sharedInstance.eventLogs.append(log)
        
        if let alert = log.alert {
            print(alert.toJSON())
            let repeatAt = sharedInstance.time + alert.time
            sharedInstance.alertLogs[repeatAt] = log
        }
        
        NSNotificationCenter.defaultCenter().postNotificationName("LogEvent", object: nil)
    }
    
    private func resetAll() {
        timerStarted = false
        eventLogs = [EventLog]()
    }
    
    func startTimer(target target: AnyObject, selector: Selector) {
        stopTimer()
        resetTimer()
        timerStarted = true
        
        codeTimerTarget = target
        codeTimerSelector = selector
        
        codeTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: "updateTime", userInfo: nil, repeats: true)
    }
    
    func stopTimer() {
        codeTimer?.invalidate()
        codeTimer = nil
        
        codeTimerSelector = nil
        codeTimerTarget = nil
    }
    
    func resetTimer() {
        time = 0
        stringTime = "00:00"
    }
    
    internal func updateTime() {
        time++
        
        if let log = alertLogs[time] {
            print(log.alert?.toJSON())
            print(log.type)
            print(log.log)
            let message = log.alert!.message
            NSNotificationCenter.defaultCenter().postNotificationName("EventAlert", object: nil, userInfo: ["message": message])
        }
        
        
        if codeTimerSelector != nil && codeTimerTarget != nil {
            codeTimerTarget!.performSelector(codeTimerSelector!, withObject: stringTime)
        }
    }
    
    func removeLogAtIndex(index: Int) {
        eventLogs.removeAtIndex(index)
        let t: CustomString = "hello"
        print(t)
    }
}

typealias JSON = [String: AnyObject]
typealias StringClosure = (String) -> ()

protocol Decodable {
    init(data: JSON)
}

protocol AdminRepresentationType {
    init()
    
    func admin_numberOfSections() -> Int
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect
    func admin_moveableSections() -> [Int]
    func admin_movedData(from from: Int, to: Int)
    func admin_deletedRow(rowIndex: Int)
    
    func admin_representationState() -> RepresentationState
    
    var adminTableDelegate: AdminTableViewControllerDelegate? { get set }
}

extension Bool {
    var stringValue: String {
        return self ? "Yes" : "No"
    }
    
    var presentValue: String {
        return self ? "Present" : "Absent"
    }
}
