//
//  File.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation


struct File {
    
    private static let codeFileName = "form-data.json"
    private static let fileDirectory: NSString = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true).first!
    
    static func getCurrentForms() -> JSON {
        let filePath = fileDirectory.stringByAppendingPathComponent(codeFileName)
        
        if let formData = NSDictionary(contentsOfFile: filePath) {
            return formData as! JSON
        } else {
            let defaultData = readDefaultJSON()
            writeNewForm(defaultData)
            return defaultData
        }
    }
    
    static func writeNewForm(newData: JSON) {
        let filePath = fileDirectory.stringByAppendingPathComponent(codeFileName)
        (newData as NSDictionary).writeToFile(filePath, atomically: true)
    }
    
    static func readDefaultJSON() -> JSON {
        let path = NSBundle.mainBundle().pathForResource("Data", ofType: "json")!
        let data = try! NSData(contentsOfFile: path, options: NSDataReadingOptions.DataReadingMappedIfSafe)
        let json = try! NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers) as! JSON
        
        return json
    }
    
}