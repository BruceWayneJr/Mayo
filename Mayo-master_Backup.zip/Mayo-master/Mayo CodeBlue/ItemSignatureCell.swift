//
//  ItemSignatureCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/13/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class ItemSignatureCell: UICollectionViewCell {
    
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var signView: SignatureView!
    private var collectionView: UICollectionView?
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    var signature: UIImage?
    var name = ""
    var item: Item?
    var delegate: CellDelegate?
    
    override func awakeFromNib() {
        layer.cornerRadius = 3
        backgroundColor = UIColor.whiteColor()
        
        signView.delegate = self
        signView.layer.borderWidth = 0.5
        
        nameField.delegate = self
        nameField.returnKeyType = .Done
        nameField.layer.cornerRadius = 3
        nameField.layer.borderWidth = 0.5
        
        updateFieldForError(isError: false)
        updateSignViewForError(isError: false)
    }
    
    func setItemData(itemData: Item, collectionView: UICollectionView) {
        item = itemData
        self.collectionView = collectionView
        
        topLabel.text = itemData.name
        nameField.text = itemData.stringValue
        if let image = itemData.image {
            signView.setImage(image)
        }
    }
    
    @IBAction func saveButtonPressed(sender: UIButton) {
        nameField.resignFirstResponder()
        
        if name != "" && signature != nil {
            item?.stringValue = name
            item?.image = signature
            
            if let log = item?.getLog() {
                delegate?.newLog(log)
            }
            
            if !item!.keep {
                nameField.text = ""
                name = ""
                
                signView.clearButtonPressed()
                signature = nil
            }
            
            updateSignViewForError(isError: false)
            updateFieldForError(isError: false)
        } else {
            updateSignViewForError(isError: signature == nil)
            updateFieldForError(isError: name == "")
        }
    }
    
    func updateSignViewForError(isError isError: Bool) {
        let color = isError ? UIColor.backgroundBrightRed() : UIColor.clearColor()
        signView.layer.borderColor = color.CGColor
    }
    
    func updateFieldForError(isError isError: Bool) {
        let color = isError ? UIColor.backgroundBrightRed() : UIColor.clearColor()
        nameField.layer.borderColor = color.CGColor
    }
}

extension ItemSignatureCell: UITextFieldDelegate {
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return false
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        name = textField.text!
    }
}

extension ItemSignatureCell: SignatureViewDelegate {
    func didBeginDrawing() {
        collectionView?.scrollEnabled = false
        collectionView?.userInteractionEnabled = false
    }
    
    func didEndDrawing(image: UIImage?) {
        signature = image
        
        collectionView?.scrollEnabled = true
        collectionView?.userInteractionEnabled = true
    }
    
    func clearedDrawing() {
        signature = nil
    }
}
