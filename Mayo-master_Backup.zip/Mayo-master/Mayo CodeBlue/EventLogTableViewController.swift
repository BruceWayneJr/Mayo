//
//  EventLogTableViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/20/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class EventLogTableViewController: UITableViewController {
    
    var logs: [EventLog]!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        logs = Mayo.sharedInstance.eventLogs
        tableView.backgroundColor = UIColor.backgroundLightGray()
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 72
        tableView.tableFooterView = UIView()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "newEventLogged", name: "LogEvent", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "newCodeInitiated", name: "NewCode", object: nil)
    }
    
    override func viewWillAppear(animated: Bool) {
        
    }
    
    func newEventLogged() {
        let lastEvent = Mayo.sharedInstance.eventLogs.last!
        logs.append(lastEvent)
        
        let newIndexPath = NSIndexPath(forRow: logs.count-1, inSection: 0)
        tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .None)
        tableView.scrollToRowAtIndexPath(newIndexPath, atScrollPosition: .Bottom, animated: true)
    }
    
    func newCodeInitiated() {
        logs = Mayo.sharedInstance.eventLogs
        tableView.reloadData()
    }
}

// MARK: - Table view data source
extension EventLogTableViewController {
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logs.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("EventLogCell", forIndexPath: indexPath) as! EventLogCell
        let currentLog = logs[indexPath.row]
        
        cell.setLogData(currentLog)
        
        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            logs.removeAtIndex(indexPath.row)
            Mayo.sharedInstance.removeLogAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        }
    }
}
