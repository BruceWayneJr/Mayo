//
//  ColorPickerViewController.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/12/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol ColorPickerDelegate {
    func didSelectColor(red red: CGFloat, blue: CGFloat, green: CGFloat)
}

class ColorPickerViewController: UIViewController {

    @IBOutlet weak var saveButton: UIButton!
    
    @IBOutlet weak var testLabel: UILabel!
    @IBOutlet weak var testView: UIView!
    
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var redSlider: UISlider!
    
    var delegate: ColorPickerDelegate?
    
    var r: CGFloat = 0
    var g: CGFloat = 0
    var b: CGFloat = 0
    
    private enum RGB: Int {
        case Red, Blue, Green
    }
    
    private var backgroundColor: UIColor {
        get {
            return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: 1.0)
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        redSlider.minimumValue = 0
        blueSlider.minimumValue = 0
        greenSlider.minimumValue = 0
        greenSlider.maximumValue = 255
        blueSlider.maximumValue = 255
        redSlider.maximumValue = 255
        
        redSlider.value = 0
        blueSlider.value = 0
        greenSlider.value = 0

        updateTestViewColors()
    }
    
    override func viewWillAppear(animated: Bool) {
        redSlider.value = Float(r)
        blueSlider.value = Float(b)
        greenSlider.value = Float(g)
    }

    func setColors(red red: CGFloat, green: CGFloat, blue: CGFloat) {
        r = red
        g = green
        b = blue
    }
    
    func updateTestViewColors() {
        testView.backgroundColor = backgroundColor
        if backgroundColor.isLight() {
            testLabel.textColor = UIColor.blackColor()
        } else {
            testLabel.textColor = UIColor.whiteColor()
        }
    }
    
    @IBAction func sliderMoved(sender: UISlider) {
        r = CGFloat(redSlider.value)
        g = CGFloat(greenSlider.value)
        b = CGFloat(blueSlider.value)
        
        updateTestViewColors()
    }

    @IBAction func saveButtonSelected(sender: UIButton) {
        delegate?.didSelectColor(red: r, blue: b, green: g)
        dismissViewControllerAnimated(true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
