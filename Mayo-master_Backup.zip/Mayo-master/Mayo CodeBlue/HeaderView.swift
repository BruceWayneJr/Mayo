//
//  HeaderView.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/19/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class HeaderView: UICollectionReusableView {
        
    @IBOutlet weak var headerLabel: UILabel!
}
