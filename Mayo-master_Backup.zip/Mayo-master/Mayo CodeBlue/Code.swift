//
//  Code.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 8/30/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Code: Decodable {
    var events = [Event]()
    var name = ""
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    required init() {
        
    }
    
    lazy var updateName: StringClosure = {
        self.name = $0 == "" ? self.name : $0
    }
    
    required init(data: JSON) {
        guard let events = data["events"] as? Array<JSON> else {
            // return error
            return
        }
        
        guard let name = data["name"] as? String else {
            print("No name for code")
            return
        }
        
        self.name = name
        for e in events {
            let eventData = Event(data: e)
            self.events.append(eventData)
        }
    }
    
    func toJSON() -> JSON {
        return [
            "events" : events.map { $0.toJSON() },
            "name" : name
        ]
    }
}

extension Code: AdminRepresentationType {
    static var adminRows = [""]
    
    func admin_numberOfSections() -> Int {
        return 3
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        if sectionIndex == 1 {
            return events.count
        } else {
            return 1
        }
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == 0 {
            return CellType.Field(name, "Name", updateName)
        } else if indexPath.section == 1 {
            let event = events[indexPath.row]
            return .Standard(event.name == "" ? "No Event Name" : event.name, "Event", events[indexPath.row].admin_representationState())
        } else {
            return .Standard("Add new Event", "", .Valid)
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return sectionIndex == 1 ? "\(events.count) event(s)" : ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• Name for Code is required"
        } else if sectionIndex == 2 {
            return "• There has to be at least 1 Event for a Code"
        }
        
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 1 {
            let event = events[indexPath.row]
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(event)
            event.adminTableDelegate = pushVC
            return .Push(pushVC)
        } else if indexPath.section == 2 {
            let newEvent = Event()
            events.append(newEvent)
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(newEvent)
            newEvent.adminTableDelegate = pushVC
            return .Push(pushVC)
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return [1]
    }
    
    func admin_movedData(from from: Int, to: Int) {
        let movedData = events.removeAtIndex(from)
        events.insert(movedData, atIndex: to)
    }
    
    func admin_deletedRow(rowIndex: Int) {
        if rowIndex >= 0 && rowIndex < events.count {
            events.removeAtIndex(rowIndex)
        }
    }
    
    func admin_representationState() -> RepresentationState {
        if name != "" {
            if events.count > 0 {
                for e in events {
                    if e.admin_representationState() == .Invalid {
                        return .Invalid
                    }
                }
                
                return .Valid
            }
        }
        
        return .Invalid
    }
}
