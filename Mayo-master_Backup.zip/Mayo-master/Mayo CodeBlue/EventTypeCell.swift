//
//  EventTypeCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class EventTypeCell: UITableViewCell {

    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeView: UIView!
    
    private var type = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setType(typeName: String) {
        type = typeName
        typeLabel.text = type.uppercaseString
        
        separatorInset = UIEdgeInsetsZero
        preservesSuperviewLayoutMargins = false
        layoutMargins = UIEdgeInsetsZero
        
        setUnselectedColors()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        selected ? setSelectedColors() : setUnselectedColors()
    }
    
    private func setSelectedColors() {
        typeView.backgroundColor = UIColor.backgroundBrightRed()
        contentView.backgroundColor = UIColor.backgroundLightGray()
        typeLabel.textColor = UIColor.whiteColor()
    }
    
    private func setUnselectedColors() {
        typeView.backgroundColor = UIColor.whiteColor()
        contentView.backgroundColor = UIColor.backgroundLightGray()
        typeLabel.textColor = UIColor.blackColor()
    }
    
    

}
