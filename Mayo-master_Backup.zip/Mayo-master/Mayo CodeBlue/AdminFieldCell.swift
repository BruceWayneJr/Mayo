//
//  AdminFieldCell.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/11/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class AdminFieldCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var valueTextField: UITextField!
    
    var updater: StringClosure?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        valueTextField.delegate = self
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension AdminFieldCell: UITextFieldDelegate {
    func textFieldDidEndEditing(textField: UITextField) {
        updater?(textField.text!)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
