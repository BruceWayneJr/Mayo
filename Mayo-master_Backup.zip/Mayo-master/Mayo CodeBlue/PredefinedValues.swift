//
//  PredefinedValues.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/12/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class PredefinedValues: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    var name = ""
    var values = [CustomString]()
    
    required init() {
        name = ""
        values = [CustomString]()
    }
    
    required init(data: JSON) {
        guard let message = data["name"] as? String else {
            print("Missing name for predefined values \(data)")
            return
        }
        
        guard let values = data["values"] as? [String] else {
            print("Missing values for predefined values \(data)")
            return
        }
        
        self.name = message
        self.values = values.map { CustomString(stringLiteral: $0) }
    }
    
    func isDefault() -> Bool {
        return values.count == 0 && name == ""
    }
    
    func toJSON() -> JSON? {
        if !isDefault() {
            return [
                "name": name,
                "values": values.map  { $0.description }
            ]
        }
        
        return nil
    }
}

extension PredefinedValues: AdminRepresentationType {    
    func admin_numberOfSections() -> Int {
        return 3
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        if sectionIndex == 1 {
            return values.count
        } else {
            return 1
        }
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == 0 {
            return .Field(name, "Name", nil)
        } else if indexPath.section == 1 {
            let value = values[indexPath.row]
            return .Standard(value.description, "Change", value.admin_representationState())
        } else {
            return .Standard("Add new Value", "", .Valid)
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 1 {
            return "\(values.count) Value(s)"
        }
        
        return ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• Name is not used for 'Choice' Item types, and is optional for 'Comment' types."
        } else if sectionIndex == 2 {
            return "• Values are required for 'Choice' types, but not for 'Comment' types."
        }
        
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 1 {
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            let value = values[indexPath.row]
            pushVC.setRepData(value)
            value.adminTableDelegate = pushVC
            return .Push(pushVC)
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return [1]
    }
    
    func admin_deletedRow(rowIndex: Int) {
        if rowIndex >= 0 && rowIndex < values.count {
            values.removeAtIndex(rowIndex)
        }
    }
    
    func admin_movedData(from from: Int, to: Int) {
        let movedData = values.removeAtIndex(from)
        values.insert(movedData, atIndex: to)
    }
    
    func admin_representationState() -> RepresentationState {
        return name == "" ? .Invalid : .Valid
    }
}
