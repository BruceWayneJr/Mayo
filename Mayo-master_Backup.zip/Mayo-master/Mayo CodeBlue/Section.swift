//
//  Section.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Section: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    var name = ""
    var numberPerRow = 0
    var view: SectionView = SectionView.Collection {
        didSet {
            for i in items {
                i.sectionType = view
            }
            adminTableDelegate?.reloadData()
        }
    }
    var items = [Item]()
    var color: Color?
    var alert: TimerAlert?
    
    required init() {
        name = ""
        numberPerRow = 0
        view = SectionView.Collection
        items = [Item]()
    }
    
    lazy var updateName: StringClosure = {
        self.name = $0
    }
    
    lazy var updateNumberPerRow: StringClosure = {
        guard let num = Int($0) else {
            return
        }
        
        self.numberPerRow = num
    }
    
    lazy var updateView: StringClosure = {
        guard let newView = SectionView(rawValue: $0) else {
            return
        }
        
        self.view = newView
    }
    
    required convenience init(data: JSON) {
        self.init()
        
        if let name = data["name"] as? String {
            self.name = name
        }
        
        guard let items = data["items"] as? Array<JSON> else {
            print("Error parsing section items \(data)")
            return
        }
        
        guard let view = data["view"] as? String else {
            print("Error parsing section view \(data)")
            return
        }
        self.view = SectionView(rawValue: view.capitalizedString)!
        
        if let numberPerRow = data["numberPerRow"] as? Int {
            self.numberPerRow = numberPerRow
            if numberPerRow > items.count {
                self.numberPerRow = items.count
            } else if numberPerRow <= 0 {
                if self.view == .Collection {
                    self.numberPerRow = items.count > 6 ? 6 : items.count
                } else {
                    self.numberPerRow = 1
                }
            }
        } else {
            self.numberPerRow = items.count > 6 ? 6 : items.count
        }
        
        if let colorData = data["color"] as? JSON {
            self.color = Color(data: colorData)
        }
        
        if let alertData = data["timerAlert"] as? JSON {
            self.alert = TimerAlert(data: alertData)
        }
        
        for item in items {
            let i = Item(data: item)
            i.sectionColor = self.color
            i.sectionAlert = self.alert
            i.sectionType = self.view
            self.items.append(i)
        }
        
        if self.view != .Collection {
            self.numberPerRow = 1
        }
    }

    func toJSON() -> JSON {
        var dict: JSON = [
            "name": name,
            "numberPerRow": numberPerRow,
            "view": view.rawValue,
            "items": items.map { $0.toJSON() }
        ]
        
        if let colorData = color?.toJSON() {
            dict["color"] = colorData
        }
        
        if let timerData = alert?.toJSON() {
            dict["timerAlert"] = timerData
        }
        
        return dict
    }
    
    private func updateTimerAlertState() {
        if alert != nil && alert!.isDefault() {
            alert = nil
        }
    }
    
    private func updateColorState() {
        if color != nil && color!.isDefault() {
            color = nil
        }
    }
    
    private func isTimerAlertValid() -> RepresentationState {
        updateTimerAlertState()
        
        if alert != nil {
            return alert!.isValid ? .Valid : .Invalid
        } else {
            return .Valid
        }
    }
}

extension Section: AdminRepresentationType {
    
    func admin_numberOfSections() -> Int {
        return 4
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        if sectionIndex == 0 {
            return 3
        } else if sectionIndex == 1 {
            return 2
        } else if sectionIndex == 2 {
            return items.count
        } else if sectionIndex == 3 {
            return 1
        }
        
        return 0
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == 0 {
            var title: String
            var subtitle: String
            var updater: StringClosure?
            let row = indexPath.row
            
            if row == 0 {
                title = name
                subtitle = "Name"
                updater = updateName
            } else if row == 1 {
                title = "\(numberPerRow)"
                subtitle = "Number per Row"
                updater = updateNumberPerRow
            } else {
                title = view.rawValue
                subtitle = "View Type"
                updater = updateView
            }
            
            return .Field(title, subtitle, updater)
        } else if indexPath.section == 1 {
            let row = indexPath.row
            var title = ""
            var subtitle = ""
            if row == 0 {
                var t = "Color"
                var st = "Color"
                if color == nil || color!.isDefault() {
                    t = "Set Color"
                    st = ""
                }
                title = t
                subtitle = st
            } else if row == 1 {
                var t = "Timer Alert"
                var st = "Timer Alert"
                if alert == nil || alert!.isDefault() {
                    t = "Set Timer Alert"
                    st = ""
                }
                title = t
                subtitle = st
            }
            return .Standard(title, subtitle, .Valid)
        } else if indexPath.section == 2 {
            let item = items[indexPath.row]
            return .Standard(item.name == "" ? "No Item Name" : item.name , "Item", item.admin_representationState())
        } else {
            return .Standard("Add new Item", "", .Valid)
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return sectionIndex == 2 ? "\(items.count) item(s)" : ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• Name is optional. \n• View Types can be Collection, List, Signature or Comment. \n• Select Collection for selectable items that can be toggled. \n• Select List for text, numeric or multiple choice entries. \n• Select Signature or Comment for signature fields or comments respectively. \n• If view type is Collection, Number per Row can be 1-6. If anything else, only 1. If this is not followed, the app will change those by itself."
        } else if sectionIndex == 1 {
            return "• Setting a Color or Timer alert for a section will set it for each of it's items. If you do not want it for every item log, add them individually for each item. \n• Colors and Timers are optional."
        } else if sectionIndex == 3 {
            return "• There has to be at least 1 Item for a Section"
        }
        
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 0 {
            if indexPath.row == 2 {
                return .Alert("Section Type", "View Style", SectionView.allStringValues)
            } else {
                return .None
            }
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                let colorPickerVC = ColorPickerViewController(nibName: "ColorPickerViewController", bundle: nil)
                let c = color ?? Color()
                colorPickerVC.setColors(red: CGFloat(c.r), green: CGFloat(c.g), blue: CGFloat(c.b))
                colorPickerVC.delegate = self
                return .Popover(colorPickerVC, CGSize(width: 212, height: 317))
            } else if indexPath.row == 1 {
                let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
                alert = alert ?? TimerAlert()
                let timer = alert!
                pushVC.setRepData(timer)
                timer.adminTableDelegate = pushVC
                return .Push(pushVC)
            }
        } else if indexPath.section == 2 {
            let item = items[indexPath.row]
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(item)
            item.adminTableDelegate = pushVC
            return .Push(pushVC)
        } else if indexPath.section == 3 {
            let newItem = Item()
            newItem.sectionType = view
            switch view {
            case .Comment:
                newItem.type = .Comment
            case .Signature:
                newItem.type = .Signature
            case .Collection:
                newItem.type = .Flag
            case .List:
                newItem.type = .Text
            }
            items.append(newItem)
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(newItem)
            newItem.adminTableDelegate = pushVC
            return .Push(pushVC)
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return [2]
    }
    
    func admin_movedData(from from: Int, to: Int) {
        let movedData = items.removeAtIndex(from)
        items.insert(movedData, atIndex: to)
    }
    
    func admin_deletedRow(rowIndex: Int) {
        if rowIndex >= 0 && rowIndex < items.count {
            items.removeAtIndex(rowIndex)
        }
    }
    
    func admin_representationState() -> RepresentationState {
        if isTimerAlertValid() == .Valid {
            if items.count > 0 {
                for item in items {
                    if item.admin_representationState() == .Invalid {
                        return .Invalid
                    }
                }
                
                return .Valid
            }
        }
        
        return .Invalid
    }
}

extension Section: ColorPickerDelegate {
    func didSelectColor(red red: CGFloat, blue: CGFloat, green: CGFloat) {
        if color == nil {
            color = Color()
        }
        
        color?.r = Int(red)
        color?.g = Int(green)
        color?.b = Int(blue)
    }
}

enum SectionView: String {
    case List, Collection, Comment, Signature
    
    var itemHeight: CGFloat {
        switch self {
        case .List: return 65
        case .Collection: return 60
        case .Comment: return 200
        case .Signature: return 200
        }
    }
    
    static var allValues = [List, Collection, Signature, Comment]
    static var allStringValues = SectionView.allValues.map { $0.rawValue }
}