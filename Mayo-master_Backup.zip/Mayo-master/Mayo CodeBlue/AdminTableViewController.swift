//
//  AdminTableViewController.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 8/29/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol AdminTableViewControllerDelegate {
    func reloadData()
}

class AdminTableViewController: UITableViewController {
    
    var dataSource = AdminDataSource()
    var repData: AdminRepresentationType!
    @IBOutlet weak var reorderButton: UIBarButtonItem!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    convenience init() {
        self.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.tableFooterView = UIView()
        tableView.backgroundColor = UIColor.backgroundLightGray()
        tableView.layoutMargins = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        
        navigationController?.navigationBar.tintColor = UIColor.blackColor()
    }
    
    override func viewWillAppear(animated: Bool) {
        tableView.reloadData()
    }
    
    func setRepData<T: AdminRepresentationType>(repData: T) {
        self.repData = repData
        dataSource.repData = repData
        
        var t = ""
        if repData is Form {
            t = "Form"
        } else if repData is Code {
            t = "Code"
        } else if repData is Event {
            t = "Event"
        } else if repData is Section {
            t = "Section"
        } else if repData is Item {
            t = "Item"
        } else if repData is TimerAlert {
            t = "Timer Alert"
        } else if repData is PredefinedValues {
            t = "PreDefined Values"
        }
        navigationItem.title = t
        
        reorderButton.enabled = dataSource.moveableSections().count > 0
    }

    @IBAction func reorderPressed(sender: UIBarButtonItem) {
        tableView.setEditing(!tableView.editing, animated: true)
        reorderButton.title = tableView.editing ? "Done" : "Reorder/Delete"
    }
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return dataSource.numberOfSections()
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.numberOfRows(sectionIndex: section)
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let type = dataSource.cellTypeForIndexPath(indexPath)
        switch type {
        case .Standard(let title, let subtitle, let repState):
            let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)

            cell.textLabel?.text = title
            cell.textLabel?.textColor = UIColor.blackColor()
            cell.detailTextLabel?.text = subtitle
            cell.selectionStyle = .Gray
            switch repState {
            case .Valid:
                cell.accessoryType = .DisclosureIndicator
                cell.accessoryView = nil
            case .Invalid:
                cell.accessoryType = .None
                cell.accessoryView = UIImageView(image: UIImage(named: "attention"))
            }
            
            
            return cell
        case .Field(let title, let subtitle, let updater):
            let cell = tableView.dequeueReusableCellWithIdentifier("AdminFieldCell", forIndexPath: indexPath) as! AdminFieldCell

            cell.titleLabel.text = subtitle
            cell.valueTextField.text = title
            cell.updater = updater
            let pushData = dataSource.didSelectRowAtIndexPath(indexPath)
            if pushData != .None {
                cell.valueTextField.userInteractionEnabled = false
            } else {
                cell.valueTextField.userInteractionEnabled = true
            }
            
            return cell
        case .Destructor(let title):
            let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
            
            cell.textLabel?.text = title
            cell.textLabel?.textColor = UIColor.backgroundBrightRed()
            cell.detailTextLabel?.text = ""
            cell.accessoryType = .None
            cell.accessoryView = nil
            cell.selectionStyle = .Gray
            
            return cell
        }
        
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return dataSource.heightForHeader(sectionIndex: section)
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dataSource.titleForSection(section)
    }
    
    override func tableView(tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return dataSource.titleForFooter(sectionIndex: section)
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        header.contentView.backgroundColor = UIColor.backgroundLightGray()
        
        header.textLabel?.font = UIFont.openSans(size: 13)
        header.textLabel?.textColor = UIColor.darkGrayColor()
        header.textLabel?.frame = header.frame
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let pushData = dataSource.didSelectRowAtIndexPath(indexPath)

        switch pushData {
        case .Push(let vcToPush):
            navigationController?.pushViewController(vcToPush, animated: true)
        case .Present(let vcToPresent):
            if vcToPresent is UIAlertController {
                vcToPresent.popoverPresentationController?.sourceView = view
                vcToPresent.popoverPresentationController?.sourceRect = tableView.cellForRowAtIndexPath(indexPath)!.frame
            }
            
            presentViewController(vcToPresent, animated: true, completion: nil)
        case .Popover(let vcToPresent, let popoverSize):
            let popover = UIPopoverController(contentViewController: vcToPresent)
            popover.popoverContentSize = popoverSize
            let f = tableView.cellForRowAtIndexPath(indexPath)!.frame
            popover.presentPopoverFromRect(f, inView: tableView, permittedArrowDirections: .Any, animated: true)
        case .Alert(let title, let message, let values):
            let optionsVC = UIAlertController(title: title, message: message, preferredStyle: .ActionSheet)
            for v in values {
                let action = UIAlertAction(title: v, style: .Default, handler: { (_) -> Void in
                    let type = self.dataSource.cellTypeForIndexPath(indexPath)
                    switch type {
                    case .Field(_, _, let updater):
                        let cell = tableView.cellForRowAtIndexPath(indexPath) as! AdminFieldCell
                        cell.valueTextField.text = v
                        updater?(v)
                    default: break
                    }
                })
                
                optionsVC.addAction(action)
            }
            
            optionsVC.popoverPresentationController?.sourceView = view
            optionsVC.popoverPresentationController?.sourceRect = tableView.cellForRowAtIndexPath(indexPath)!.frame
            presentViewController(optionsVC, animated: true, completion: nil)
        case .Reload: tableView.reloadData()
        case .None: break
        }
    }
    
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return dataSource.canMoveRowAtIndexPath(indexPath)
    }
    
    override func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath) {
        if sourceIndexPath.row != destinationIndexPath.row {
            dataSource.movedData(from: sourceIndexPath.row, to: destinationIndexPath.row)
        }
    }
    
    override func tableView(tableView: UITableView, targetIndexPathForMoveFromRowAtIndexPath sourceIndexPath: NSIndexPath, toProposedIndexPath proposedDestinationIndexPath: NSIndexPath) -> NSIndexPath {
        
        return sourceIndexPath.section != proposedDestinationIndexPath.section ? sourceIndexPath : proposedDestinationIndexPath
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return dataSource.canMoveRowAtIndexPath(indexPath)
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            let alertVC = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this? It cannot be undone", preferredStyle: .Alert)
            let okAction = UIAlertAction(title: "Ok", style: .Default, handler: { (_) -> Void in
                self.dataSource.deleteData(rowIndex: indexPath.row)
                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
            })
            let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: { (_) -> Void in
                print("cancel")
            })
            alertVC.addAction(okAction)
            alertVC.addAction(cancelAction)
            presentViewController(alertVC, animated: true, completion: nil)
        }
    }
}

extension AdminTableViewController: AdminTableViewControllerDelegate {
    func reloadData() {
        tableView.reloadData()
    }
}
