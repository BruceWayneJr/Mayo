//
//  EventLog.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 6/27/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

struct EventLog {
    var log = ""
    var time = NSDate()
    var timerTime = ""
    var type = ""
    var alert: TimerAlert?
    var color: UIColor?
}
