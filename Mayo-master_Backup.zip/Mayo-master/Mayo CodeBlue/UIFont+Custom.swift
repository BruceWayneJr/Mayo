//
//  UIFont+Custom.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/11/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

extension UIFont {
    static func openSans(size size: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans", size: size)!
    }
    
    static func openSansLight(size size: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Light", size: size)!
    }
    
    static func openSansBold(size size: CGFloat) -> UIFont {
        return UIFont(name: "OpenSans-Bold", size: size)!
    }
}
