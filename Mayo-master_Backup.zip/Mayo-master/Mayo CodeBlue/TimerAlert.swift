//
//  TimerAlert.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation

class TimerAlert: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    var message: String = "" {
        didSet {
            updateValidity()
        }
    }
    var time: Int = 0 {
        didSet {
            updateValidity()
        }
    }
    var isValid = false
    
    required init() {    
        message = ""
        time = 0
        isValid = false
    }
    
    lazy var updateMessage: StringClosure = {
        self.message = $0
        print("Message updated \($0)")
    }
    
    lazy var updateTime: StringClosure = {
        if let time = Int($0) {
            self.time = time
            print("time updated \($0)")
        }
    }
    
    required init(data: JSON) {
        guard let message = data["message"] as? String else {
            isValid = false
            print("Missing message for alert \(data)")
            return
        }
        
        guard let time = data["time"] as? Int else {
            isValid = false
            print("Missing time for alert \(data)")
            return
        }
        
        if time < 0 {
            isValid = false
            print("Time is negetive \(time)")
            return
        }
        
        self.message = message
        self.time = time
        
        isValid = message.characters.count > 0 && time > 0
    }
    
    func isDefault() -> Bool {
        return message == "" && time == 0
    }
    
    func toJSON() -> JSON? {
        if !isDefault() {
            return [
                "message": message,
                "time": time
            ]
        }
        
        return nil
    }

    private func updateValidity() {
        isValid = message.characters.count > 0 && time > 0
    }
}

extension TimerAlert: AdminRepresentationType {
    func admin_numberOfSections() -> Int {
        return 2
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        return sectionIndex == 0 ? 2 : 1
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                return .Field(message, "Message", updateMessage)
            } else {
                return .Field("\(time)", "Time (Seconds)", updateTime)
            }
        } else {
            return .Destructor("Remove Timer")
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• Both a message and a time are required. \n• Time is in seconds."
        }
        
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 1 {
            isValid = false
            message = ""
            time = 0
            
            adminTableDelegate?.reloadData()
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return []
    }
    
    func admin_movedData(from from: Int, to: Int) {
        
    }
    
    func admin_deletedRow(rowIndex: Int) {
        
    }
    
    func admin_representationState() -> RepresentationState {
        return isValid ? .Valid : .Invalid
    }
}