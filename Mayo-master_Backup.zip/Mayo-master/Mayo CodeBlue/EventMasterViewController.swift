//
//  EventMasterViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/13/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol MasterViewDelegate {
    func updateSelectedIndex(index: Int)
}

class EventMasterViewController: UIViewController, MasterViewDelegate {
    
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var timerButton: UIButton!
    var detailViewController: DetailViewController? = nil
    var typeTableViewcontroller: EventTypeTableViewController? = nil
    var selectedIndex = 0
    
    private var timerStarted = false
    
    override func viewDidLoad() {
        splitViewController?.preferredDisplayMode = .AllVisible
        splitViewController?.maximumPrimaryColumnWidth = 225
        
        let controllers = splitViewController!.viewControllers
        self.detailViewController = controllers[controllers.count-1] as? DetailViewController
        
        view.backgroundColor = UIColor.backgroundLightGray()
        
        timerLabel.text = "00:00"
        timerLabel.backgroundColor = UIColor.backgroundLightGray()
        
        timerButton.setTitle("START", forState: .Normal)
        timerButton.setTitle("STOP", forState: .Selected)
        timerButton.setTitleColor(UIColor.backgroundBrightRed(), forState: .Normal)
        timerButton.setTitleColor(UIColor.whiteColor(), forState: .Selected)
        timerButton.backgroundColor = UIColor.whiteColor()
        timerButton.tintColor = UIColor.clearColor()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "manuallyStart", name: "ManualStart", object: nil)
        
        
    }
    
    func manuallyStart() {
        timerButtonSelected(timerButton)
    }

    @IBAction func timerButtonSelected(sender: UIButton) {
        sender.selected = !sender.selected
        
        if !timerStarted {
            timerStarted = true
            sender.backgroundColor = UIColor.backgroundBrightRed()
            Mayo.sharedInstance.startTimer(target: self, selector: "updateTimer:")
        } else {
            timerStarted = false
            sender.backgroundColor = UIColor.whiteColor()
            Mayo.sharedInstance.stopTimer()
        }
    }
    
    func updateTimer(time: String) {
        timerLabel.text = time
    }
    
    func updateSelectedIndex(index: Int) {
        selectedIndex = index
        detailViewController?.selectedIndex = selectedIndex
    }
    @IBAction func menuButtonPreesed(sender: UIButton) {
        navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func resetButtonSelected(sender: UIButton) {
        let alert = UIAlertController(title: "Confirm", message: "Are you sure you want to reset all fields?", preferredStyle: .Alert)
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (_) -> Void in }
        alert.addAction(cancel)
        
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default) { (_) -> Void in
            if self.timerStarted {
                self.timerButtonSelected(self.timerButton)
            }
            
            Mayo.newCode()
            self.updateSelectedIndex(0)
            self.timerLabel.text = "00:00"
            self.typeTableViewcontroller?.updateData(Mayo.sharedInstance.code.events
            )
            self.typeTableViewcontroller?.setSelectedIndex(0)
        }
        alert.addAction(ok)
        
        presentViewController(alert, animated: true, completion: nil)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "TypeList" {
            let vc = segue.destinationViewController as! EventTypeTableViewController
            typeTableViewcontroller = vc
            vc.delegate = self
        }
    }
}
