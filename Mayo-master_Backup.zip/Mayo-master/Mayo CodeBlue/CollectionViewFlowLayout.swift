//
//  CollectionViewFlowLayout.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/19/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class CollectionViewFlowLayout: UICollectionViewFlowLayout {
    var dataSource = EventDataSource(event: Event())
    
    init(event: Event) {
        super.init()
        
        dataSource = EventDataSource(event: event)
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        minimumInteritemSpacing = 8
        minimumLineSpacing = 8
        
        headerReferenceSize = CGSize(width: CGRectGetWidth(collectionView!.frame), height: 50)
        sectionInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
    }
    
    override func collectionViewContentSize() -> CGSize {
        return CGSize(width: CGRectGetWidth(collectionView!.frame), height: dataSource.contentHeight())
    }
    
    override func prepareLayout() {
        let rect = CGRect(origin: CGPoint(x: 0, y: 0), size: collectionViewContentSize())
        let attributes = super.layoutAttributesForElementsInRect(rect)!

        for att in attributes {
            let indexPath = att.indexPath
            if att.representedElementCategory == UICollectionElementCategory.Cell {
                att.frame = layoutAttributesForItemAtIndexPath(indexPath)!.frame
            }
            
            if att.representedElementCategory == UICollectionElementCategory.SupplementaryView {
                att.frame = layoutAttributesForSupplementaryViewOfKind(UICollectionElementKindSectionHeader, atIndexPath: indexPath)!.frame
            }
        }
    }
    
    override func layoutAttributesForSupplementaryViewOfKind(elementKind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes? {
        let attributes = super.layoutAttributesForSupplementaryViewOfKind(elementKind, atIndexPath: indexPath)!.copy() as! UICollectionViewLayoutAttributes

        var frame = attributes.frame
        frame.origin.y = dataSource.sectionHeaderYsForSection(indexPath.section)
        frame.origin.x = 0
        attributes.frame = frame
        
        return attributes
    }
    
    override func layoutAttributesForItemAtIndexPath(indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes? {
        let attributes = super.layoutAttributesForItemAtIndexPath(indexPath)!.copy() as! UICollectionViewLayoutAttributes
        
        let section = dataSource.sectionAtIndex(indexPath.section)
        let numberPerRow = section.numberPerRow
        
        let numInRow = Int(dataSource.numberPerRow(indexPath))
        let size = dataSource.sizeForItemAtIndexPath(indexPath, collectionView: collectionView!)
        let itemCount = section.items.count
        
        if itemCount <= numInRow {
            var frame = attributes.frame
            frame.origin.x = CGFloat(indexPath.row)*size.width + (CGFloat(indexPath.row)+1)*8
            frame.origin.y = dataSource.sectionItemsMinYForIndex(indexPath.section)
            
            attributes.frame = frame
            
            return attributes
        } else {
            if indexPath.row == 0 {
                var frame = attributes.frame
                frame.origin.x = 8 
                frame.origin.y = dataSource.sectionItemsMinYForIndex(indexPath.section)
                
                attributes.frame = frame
                
                return attributes
            } else {
                let firstFrame = layoutAttributesForItemAtIndexPath(NSIndexPath(forItem: 0, inSection: indexPath.section))!.copy().frame
                let columnNum = CGFloat(indexPath.item) % CGFloat(numberPerRow)
                let rowNum: CGFloat = CGFloat(Int(indexPath.item / numberPerRow))
                
                if numberPerRow == numInRow {
                    var x: CGFloat
                    var y: CGFloat
                    
                    y = rowNum == 0 ? CGRectGetMinY(firstFrame) : CGRectGetMaxY(firstFrame) + (8*rowNum) + (size.height*(rowNum-1))
                    x = columnNum == 0 ? 8 : CGRectGetMaxX(firstFrame) + (8*columnNum) + (size.width*(columnNum-1))
                    
                    var frame = attributes.frame
                    frame.origin.x = x
                    frame.origin.y = y
                    
                    attributes.frame = frame
                } else {
                    if columnNum == 0 {
                        var frame = attributes.frame
                        frame.origin.x = 8
                        frame.origin.y = CGRectGetMaxY(firstFrame) + (8*rowNum) + (size.height*(rowNum-1))
                        
                        attributes.frame = frame
                        
                        return attributes
                    }
                    
                    let firstFrameInRow = layoutAttributesForItemAtIndexPath(NSIndexPath(forItem: (itemCount-numInRow), inSection: indexPath.section))!.copy().frame
                    var x: CGFloat
                    var y: CGFloat
                    
                    y = CGRectGetMinY(firstFrameInRow)
                    x = columnNum == 0 ? 8 : CGRectGetMaxX(firstFrameInRow) + (8*columnNum) + (size.width*(columnNum-1))
                    
                    var frame = attributes.frame
                    frame.origin.x = x
                    frame.origin.y = y
                    
                    attributes.frame = frame
                }
                
                return attributes
            }
        }
    }
}