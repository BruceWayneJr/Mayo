//
//  Color.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Color: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    var r = 255
    var g = 255
    var b = 255
    
    var uicolor: UIColor?
    
    required init() {
        r = 255
        g = 255
        b = 255
    }
    
    required init(data: JSON) {
        guard let r = data["r"] as? Int else {
            print("r missing in data \(data)")
            return
        }
        
        guard let g = data["g"] as? Int else {
            print("g missing in data \(data)")
            return
        }
        
        guard let b = data["b"] as? Int else {
            print("b missing in data \(data)")
            return
        }
        
        self.r = r
        self.g = g
        self.b = b
        
        self.uicolor = UIColor(red: CGFloat(r)/255.0, green: CGFloat(g)/255.0, blue: CGFloat(b)/255.0, alpha: 1.0)
    }
    
    func isDefault() -> Bool {
        return r == 255 && g == 255 && b == 255
    }
    
    func toJSON() -> JSON? {
        if isDefault() {
            return nil
        } else {
            return [
                "r": Int(r),
                "g": Int(g),
                "b": Int(b)
            ]
        }
    }
}

// dont use admin table vc for editing color so useless here
extension Color: AdminRepresentationType {
    func admin_numberOfSections() -> Int {
        return 1
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        return 1
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        return .Standard("test", "test", .Valid)
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return []
    }
    
    func admin_movedData(from from: Int, to: Int) {
        
    }
    
    func admin_deletedRow(rowIndex: Int) {
        
    }

    func admin_representationState() -> RepresentationState {
        return .Valid
    }
}
