//
//  Item.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Item: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    //MARK: decodable values
    var type: ItemType = ItemType.Flag {
        didSet {
            adminTableDelegate?.reloadData()
        }
    }
    var name = ""
    var detail = ""
    var value: AnyObject = 0
    var logMessage = ""
    var placeholder = ""
    var alert: TimerAlert?
    var predefinedValues: PredefinedValues?
    var color: Color?
    var keep = false
    
    //MARK: other values
    var boolValue = false
    var stringValue = ""
    var image: UIImage?
    var sectionColor: Color?
    var sectionAlert: TimerAlert?
    var sectionType: SectionView = .Collection
    
    required init() {
        type = ItemType.Flag
        name = ""
        detail = ""
        placeholder = ""
        value = 0
        logMessage = ""
    }
    
    lazy var updateName: StringClosure = {
        self.name = $0 == "" ? self.name : $0
    }
    
    lazy var updateDetail: StringClosure = {
        self.detail = $0
    }
    
    lazy var updateView: StringClosure = {
        guard let newView = ItemType(rawValue: $0) else {
            return
        }
        
        self.type = newView
    }
    
    lazy var updateLogMessage: StringClosure = {
        self.logMessage = $0 == "" ? self.logMessage : $0
    }
    
    lazy var updatePlaceholder: StringClosure = {
        self.placeholder = $0
    }
    
    lazy var updateKeep: StringClosure = {
        if $0 == "Yes" {
            self.keep = true
        } else if $0 == "No" {
            self.keep = false
        }
    }
    
    required convenience init(data: JSON) {
        self.init()
        
        guard let name = data["name"] as? String else {
            print("Error parsing item name \(data)")
            return
        }
        
        guard let type = data["type"] as? String else {
            print("Error parsing item type \(data)")
            return
        }
        
        guard let logMessage = data["logMessage"] as? String else {
            print("Error parsing item logmessage \(data)")
            return
        }
        
        if let value = data["value"] {
            self.value = value
            
            if value is Bool {
                boolValue = value as! Bool
            } else {
                stringValue = "\(value)"
            }
        }
        
        if let keep = data["keep"] as? Bool {
            self.keep = keep
        }
        
        if let detail = data["detail"] as? String {
            self.detail = detail
        }
        
        if let placeholder = data["placeholder"] as? String {
            self.placeholder = placeholder
        } else {
            self.placeholder = "Enter Here"
        }
        
        if let alertData = data["timerAlert"] as? JSON {
            self.alert = TimerAlert(data: alertData)
        }
        
        if let predefinedValues = data["predefinedValues"] as? JSON {
            self.predefinedValues = PredefinedValues(data: predefinedValues)
        }
        
        if let colorData = data["color"] as? JSON {
            self.color = Color(data: colorData)
        }
                
        self.name = name
        self.type = ItemType(rawValue: type.capitalizedString)!
        self.logMessage = logMessage
        
        switch self.type {
        case .Flag:
            self.keep = true
        case .Value:
            self.keep = false
        case .Choice, .Comment, .Signature, .Text, .Numeric: break
        }
    }
    
    func toJSON() -> JSON {
        var dict: JSON = [
            "type": type.rawValue,
            "name": name,
            "value": value,
            "logMessage": logMessage,
            "keep": keep,
            "detail": detail,
            "placeholder": placeholder
        ]
        
        if let colorData = color?.toJSON() {
            dict["color"] = colorData
        }
        
        if let timerData = alert?.toJSON() {
            dict["timerAlert"] = timerData
        }
        
        if let predefinedValuesData = predefinedValues?.toJSON() {
            dict["predefinedValues"] = predefinedValuesData
        }
        
        return dict
    }
    
    func getLog() -> EventLog? {
        var eventLog = EventLog()
        var message = ""
        
        switch type {
        case .Flag:
            if boolValue {
                message = "\(logMessage) \(boolValue.stringValue)"
            }
        case .Text, .Numeric:
            message = stringValue != "" ? logMessage + stringValue + detail : ""
        case .Value:
            message = logMessage
        case .Comment:
            message = stringValue != "" ? logMessage + stringValue : ""
        case .Signature:
            message = stringValue != "" ? "'" + stringValue + "' " + logMessage + " " + name : ""
        case .Choice:
            if let value = predefinedValues?.values[Int(stringValue)!] {
                 message = value.description != "" ? logMessage + value.description : ""
            } else {
                message = ""
            }
        }
        
        resetValuesIfNeeded()
        
        if message != "" {
            if alert != nil {
                alert?.toJSON()
            } else if sectionAlert != nil {
                sectionAlert?.toJSON()
            }
            
            eventLog.log = message
            eventLog.time = NSDate()
            eventLog.alert = alert ?? sectionAlert
            eventLog.color = (color ?? sectionColor)?.uicolor
            
            return eventLog
        }
        
        return nil
    }
    
    private func resetValuesIfNeeded() {
        if !keep {
            switch type {
            case .Flag, .Value:
                boolValue = false
            case .Text, .Numeric, .Comment, .Signature, .Choice:
                stringValue = ""
                image = nil
            }
        }
    }
    
    private func needsPredefinedValues() -> Bool {
        switch type {
        case .Choice: return true
        default: return false
        }
    }
    
    private func wantsPredefinedValues() -> Bool {
        switch type {
        case .Choice, .Comment: return true
        default: return false
        }
    }
    
    private func updateTimerAlertState() {
        if alert != nil && alert!.isDefault() {
            alert = nil
        }
    }
    
    private func updatePredefinedValuesState() {
        if predefinedValues != nil && predefinedValues!.isDefault() {
            predefinedValues = nil
        }
    }
    
    private func updateColorState() {
        if color != nil && color!.isDefault() {
            color = nil
        }
    }
    
    private func isTimerAlertValid() -> RepresentationState {
        updateTimerAlertState()
        
        if alert != nil {
            return alert!.isValid ? .Valid : .Invalid
        } else {
            return .Valid
        }
    }
    
    private func isPredefinedValuesValid() -> RepresentationState {
        updatePredefinedValuesState()
        
        if needsPredefinedValues() {
            return predefinedValues != nil ? .Valid : .Invalid
        } else {
            return .Valid
        }
    }
    
    private func validTypesForSection() -> [ItemType] {
        switch sectionType {
        case .List:
            return [.Numeric, .Text, .Choice]
        case .Collection:
            return[.Flag, .Value]
        case .Signature:
            return [.Signature]
        case .Comment:
            return [.Comment]
        }
    }
}

extension Item: AdminRepresentationType {
    
    func admin_numberOfSections() -> Int {
        return 2
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        if sectionIndex == 0 {
            return 6
        } else if sectionIndex == 1 {
            return 3
        }
        
        return 0
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        updateColorState()
        
        if indexPath.section == 0 {
            var title = ""
            var subtitle = ""
            var updater: StringClosure?
            let row = indexPath.row
            
            if row == 0 {
                title = name
                subtitle = "Name"
                updater = updateName
            } else if row == 1 {
                title = "\(detail)"
                subtitle = "Detail"
                updater = updateDetail
            } else if row == 2 {
                title = type.rawValue
                subtitle = "View Type"
                updater = updateView
            } else if row == 3 {
                title = logMessage
                subtitle = "Log Message"
                updater = updateLogMessage
            } else if row == 4 {
                title = placeholder
                subtitle = "Placeholder"
                updater = updatePlaceholder
            } else if row == 5 {
                title = keep.stringValue
                subtitle = "Keep after Log"
                updater = updateKeep
            }
            
            return .Field(title, subtitle, updater)
        } else {
            var title = ""
            var subtitle = ""
            var valid: RepresentationState = .Valid
            let row = indexPath.row
            
            if row == 0 {
                var t = "Color"
                var st = "Color"
                if color == nil {
                    t = "Set Color"
                    st = ""
                }
                title = t
                subtitle = st
                valid = .Valid
            } else if row == 1 {
                var t = "Predefined Values"
                var st = "Predefined Values"
                valid = isPredefinedValuesValid()
                if wantsPredefinedValues() {
                    if predefinedValues == nil {
                        t = "Set Predefined Values"
                        st = ""
                    }
                } else {
                    t = "No Predefined Values needed for \(type) view type"
                    st = ""
                }
                title = t
                subtitle = st
            } else if row == 2 {
                var t = "Timer Alert"
                var st = "Timer Alert"
                valid = isTimerAlertValid()
                
                if alert == nil {
                    t = "Set Timer Alert"
                    st = ""
                }
                title = t
                subtitle = st
            }

            return .Standard(title, subtitle, valid)
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• All values here are optional but nice to have. \n• Only 'Flag' and 'Value' view types can be used for 'Collection' section view type. \n• Only 'Text', 'Numeric' and 'Choice' view types can be used for 'List' section view type. \n• Only 'Comment' and 'Signature' view types can be used with 'Comment' and 'Signature' section view type respectively. \n• Keep after Log is not needed for Flag, Value or Choice types. \n• There are different rules to logging for different view types - \n    - Flag - \"Log Message\" Yes. (Only logs when set to Yes \n    - Value - \"Log Message\" \n    - Text/Numeric - \"Log Message\" \"Input Value\" \"Detail\" \n    - Comment - \"Log Message\" \"Input Value\" \n    - Signature - \"Input Value\" \"Log Message\" \"Name\" \n    - Choice - \"Log Message\" \"Input Value\""
        } else if sectionIndex == 1 {
            return "• Color and Timer Alerts are optional. \n• If Colors or Timers are set for the parent Section, they will automatically be used here during a code. If there is a Color or Timer in both an Item and it's parent section, then the item Color/Timer data would be used. \n• Predefined Values are only needed for 'Choice' types, but can also be used for 'Comment' types."
        }
        
        return ""
    }
    
    func admin_movedData(from from: Int, to: Int) {
        
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 0 {
            if indexPath.row == 2 {
                return .Alert("View Type", "Style", validTypesForSection().map { $0.rawValue })
            } else if indexPath.row == 5 {
                return .Alert("Keep after Log", "Should value be erased after logging", ["Yes", "No"])
            }
        } else {
            if indexPath.row == 0 {
                let colorPickerVC = ColorPickerViewController(nibName: "ColorPickerViewController", bundle: nil)
                color = color ?? Color()
                let c = color!
                colorPickerVC.setColors(red: CGFloat(c.r), green: CGFloat(c.g), blue: CGFloat(c.b))
                colorPickerVC.delegate = self
                
                return .Popover(colorPickerVC, CGSize(width: 212, height: 317))
            } else if indexPath.row == 1 {
                if wantsPredefinedValues() {
                    let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
                    predefinedValues = predefinedValues ?? PredefinedValues()
                    let pre = predefinedValues!
                    pushVC.setRepData(pre)
                    pre.adminTableDelegate = pushVC
                    return .Push(pushVC)
                } else {
                    return .None
                }
            } else if indexPath.row == 2 {
                let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
                alert = alert ?? TimerAlert()
                let timer = alert!
                pushVC.setRepData(timer)
                timer.adminTableDelegate = pushVC
                return .Push(pushVC)
            }
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return []
    }
    
    func admin_deletedRow(rowIndex: Int) {
        
    }
    
    func admin_representationState() -> RepresentationState {
        if isPredefinedValuesValid() == .Valid && isTimerAlertValid() == .Valid {
            if validTypesForSection().contains(type) {
                return .Valid
            } else {
                return .Invalid
            }
        }
        
        return .Invalid
    }
}

extension Item: ColorPickerDelegate {
    func didSelectColor(red red: CGFloat, blue: CGFloat, green: CGFloat) {
        if color == nil {
            color = Color()
        }
        
        color?.r = Int(red)
        color?.g = Int(green)
        color?.b = Int(blue)
    }
}

enum ItemType: String {
    case Flag, Value, Text, Numeric, Comment, Signature, Choice
    
    static var allValues = [Flag, Value, Text, Numeric, Comment, Signature, Choice]
    static var allRawValues = ItemType.allValues.map { $0.rawValue }
}