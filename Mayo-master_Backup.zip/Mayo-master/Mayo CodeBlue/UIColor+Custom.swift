//
//  UIColor+Custom.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/11/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

extension UIColor {
    
    class func backgroundLightGray() -> UIColor {
        return UIColor(red: 233/255.0, green: 232/255.0, blue: 233/255.0, alpha: 1.0)
    }
    
    class func backgroundDarkerGray() -> UIColor {
        return UIColor(red: 207/255.0, green: 207/255.0, blue: 207/255.0, alpha: 1.0)
    }
    
    class func backgroundLightRed() -> UIColor {
        return UIColor(red: 252/255.0, green: 242/255.0, blue: 242/255.0, alpha: 1.0)
    }
    
    
    class func backgroundBrightRed() -> UIColor {
        return UIColor(red: 188/255.0, green: 9/255.0, blue: 9/255.0, alpha: 1.0)
    }
    
    func isLight() -> Bool {
        let components = CGColorGetComponents(self.CGColor)
        let b = (components[0] * 299) + (components[1] * 587) + (components[2] * 114)
        let brightness = b/1000
        
        return brightness >= 0.5
    }
    
    func darkerColor() -> UIColor {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        
        if getRed(&r, green: &g, blue: &b, alpha: &a) {
            return UIColor(red: min(r-0.2, 1.0), green: min(g-0.2, 1.0), blue: min(b-0.2, 1.0), alpha: a)
        }
        
        return self
    }
    
}