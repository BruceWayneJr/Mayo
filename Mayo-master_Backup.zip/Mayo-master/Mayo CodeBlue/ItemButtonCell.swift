//
//  ItemButtonCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/19/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class ItemButtonCell: UICollectionViewCell {
    
    @IBOutlet weak var itemLabel: UILabel!
    private var item: Item!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        backgroundColor = UIColor.whiteColor()
        layer.cornerRadius = 3
    }
    
    func setItemData(item: Item) {
        self.item = item        
        itemLabel.text = item.name
        
        selected = item.boolValue
        setSelectedColors(item.boolValue)
    }
    
    func setSelectedColors(isSelected: Bool) {
        backgroundColor = isSelected ? UIColor.backgroundBrightRed() : UIColor.whiteColor()
        itemLabel.textColor = isSelected ? UIColor.whiteColor() : UIColor.blackColor()
    }
    
    override var highlighted: Bool {
        didSet {
            backgroundColor = highlighted ? UIColor.backgroundBrightRed() : UIColor.whiteColor()
            itemLabel.textColor = highlighted ? UIColor.whiteColor() : UIColor.blackColor()
        }
    }
}
