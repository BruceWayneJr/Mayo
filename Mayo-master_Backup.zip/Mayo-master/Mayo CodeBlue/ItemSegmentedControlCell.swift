//
//  ItemSegmentedControlCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/22/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class ItemSegmentedControlCell: UICollectionViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    private var item: Item!
    var delegate: CellDelegate?
    
    override func awakeFromNib() {
        segmentedControl.backgroundColor = UIColor.clearColor()
        segmentedControl.tintColor = UIColor.backgroundBrightRed()
        segmentedControl.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "OpenSans", size: 15)!], forState: .Normal)
        segmentedControl.setTitleTextAttributes([NSFontAttributeName: UIFont(name: "OpenSans", size: 15)!], forState: .Selected)
        
        backgroundColor = UIColor.whiteColor()
    }

    func setItemData(itemData: Item) {
        self.item = itemData
        
        segmentedControl.removeAllSegments()
        for (index, value) in item.predefinedValues!.values.enumerate() {
            segmentedControl.insertSegmentWithTitle(value.description, atIndex: index, animated: false)
        }
        
        if item.stringValue == "" {
            segmentedControl.selectedSegmentIndex = UISegmentedControlNoSegment
        } else {
            if let selectedValue = Int(item.stringValue) {
                segmentedControl.selectedSegmentIndex = selectedValue
            } else {
                segmentedControl.selectedSegmentIndex = UISegmentedControlNoSegment
            }
        }
        
        nameLabel.text = item.name
    }
    
    @IBAction func valueDidChange(sender: UISegmentedControl) {
        item.stringValue = "\(sender.selectedSegmentIndex)"
        
        if let log = item.getLog() {
            delegate?.newLog(log)
        }
        
        if !item.keep {
            segmentedControl.selectedSegmentIndex = UISegmentedControlNoSegment
        }
    }
}
