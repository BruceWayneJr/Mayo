//
//  HemodynamicsDataModel.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/15/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation

typealias CellData = (title: String, detail: String)

struct DataModel {
    static func dataAtIndex(index: Int, section: Int) -> CellData {
        if section == 0 { // cpr
            switch index {
            case 0:
                return ("CPR", "Absent")
            case 1:
                return ("Pause CPR", "")
            default:
                return ("", "")
            }
        }
        
        return ("", "")
    }
    
    static func didSelectRowAtIndex(index: Int, section: Int) {
        if section == 0 { // cpr
            switch index {
            case 0:
                CodeBlue.sharedEvent.hemodynamics.cpr = true
            case 1:
                CodeBlue.sharedEvent.hemodynamics.cpr = true
            default:
                CodeBlue.sharedEvent.hemodynamics.cpr = true
            }
        }
    }
}
