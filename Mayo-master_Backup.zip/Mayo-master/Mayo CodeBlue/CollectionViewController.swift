//
//  CollectionViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {
    
    var data = Event()
    var dataSource: EventDataSource!
    var selectedIndex = 0 {
        didSet {
            data = Mayo.sharedInstance.code.events[selectedIndex]
            dataSource = EventDataSource(event: data)
            layout?.dataSource = dataSource
            collectionView?.reloadData()
        }
    }
    var layout: CollectionViewFlowLayout?

    override func viewDidLoad() {
        super.viewDidLoad()
        data = Mayo.sharedInstance.code.events[selectedIndex]
        
        dataSource = EventDataSource(event: data)

        // Register cell classes
        self.collectionView!.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        self.collectionView!.registerClass(UICollectionReusableView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "View")
        
        layout = CollectionViewFlowLayout(event: data)
        collectionView?.collectionViewLayout = layout!
        collectionView?.backgroundColor = UIColor(red: 220/255.0, green: 220/255.0, blue: 220/255.0, alpha: 1.0)
        collectionView?.allowsMultipleSelection = true
        
        collectionView?.alwaysBounceVertical = true
    }
    
    func sendLog(message: String) {
        var eventLog = EventLog()
        eventLog.log = message
        eventLog.type = dataSource.event.name
        eventLog.time = NSDate()
        
        Mayo.logEvent(eventLog)
    }
}

// MARK: UICollectionViewDataSource
extension CollectionViewController {
    
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return dataSource.numberOfSections()
    }
    
    
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource.numberOfItemsInSection(section)
    }
    
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let section = dataSource.sectionAtIndex(indexPath.section)
        let item = dataSource.itemForSection(indexPath.section, atIndex: indexPath.item)
        switch section.view {
        case .Collection:
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ItemButtonCell", forIndexPath: indexPath) as! ItemButtonCell
            cell.setItemData(item)
            
            return cell
        case .List:
            switch(item.type) {
            case .Value, .Flag, .Comment, .Signature: return UICollectionViewCell()
            case .Text, .Numeric:
                let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ItemFieldCell", forIndexPath: indexPath) as! ItemFieldCell
                cell.setItemData(item, collectionView: collectionView)
                cell.delegate = self
                
                return cell
            case .Choice:
                let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ItemSegmentedControlCell", forIndexPath: indexPath) as! ItemSegmentedControlCell
                cell.setItemData(item)
                cell.delegate = self
                
                return cell
            }
        case .Comment:
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ItemCommentCell", forIndexPath: indexPath) as! ItemCommentCell
            cell.setItemData(item, collectionView: collectionView)
            cell.delegate = self
            
            return cell
        case .Signature:
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ItemSignatureCell", forIndexPath: indexPath) as! ItemSignatureCell
            cell.setItemData(item, collectionView: collectionView)
            cell.delegate = self
            
            return cell
        }
    }
    
    override func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryViewOfKind(UICollectionElementKindSectionHeader, withReuseIdentifier: "HeaderView", forIndexPath: indexPath) as! HeaderView
        header.headerLabel.text = dataSource.sectionAtIndex(indexPath.section).name
        return header
    }
    
}

// MARK: UICollectionViewDelegateFlowLayout
extension CollectionViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return dataSource.sizeForItemAtIndexPath(indexPath, collectionView: collectionView)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if dataSource.sectionAtIndex(section).name != "" {
            return CGSize(width: CGRectGetWidth(collectionView.frame), height: 40)
        }
        
        return CGSizeZero
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 8
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 8
    }
}

// MARK: UICollectionViewDelegate
extension CollectionViewController {
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        itemSelected(indexPath)
    }
    
    override func collectionView(collectionView: UICollectionView, didDeselectItemAtIndexPath indexPath: NSIndexPath) {
        itemSelected(indexPath)
    }
    
    func itemSelected(indexPath: NSIndexPath) {
        let item = dataSource.itemForSection(indexPath.section, atIndex: indexPath.item)
        
        if item.type == .Value || item.type == .Flag {
            let cell = collectionView!.cellForItemAtIndexPath(indexPath) as! ItemButtonCell
            
            item.boolValue = !item.boolValue
            
//            var log = ""
//            if item.type == .Value {
//                item.boolValue = false
//                log = item.logMessage
//                print(log)
//            }
//            else {
//                if item.boolValue {
//                    var stringValue = ""
//                    if item.value is Bool {
//                        stringValue = item.boolValue.stringValue
//                    } else if item.value is String {
//                        stringValue = item.stringValue
//                    }
//                    log = "\(item.logMessage)\(stringValue)"
//                    print(log)
//                }
//                
//            }
            
            var eventLog = item.getLog()
            if eventLog != nil {
                eventLog!.type = dataSource.event.name
                Mayo.logEvent(eventLog!)
            }
            
            cell.setSelectedColors(item.boolValue)
            
//            if log != "" {
//                sendLog(log)
//            }
        }
    }
}

extension CollectionViewController: CellDelegate {
    func newLog(message: String) {
        sendLog(message)
    }
    
    func newLog(var log: EventLog) {
        log.type = dataSource.event.name
        Mayo.logEvent(log)
    }
}
