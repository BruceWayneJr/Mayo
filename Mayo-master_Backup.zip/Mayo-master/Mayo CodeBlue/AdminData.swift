//
//  AdminData.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/11/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

enum CellType {
    case Standard(String, String, RepresentationState), Field(String, String, StringClosure?), Destructor(String)
}

enum RepresentationState {
    case Valid, Invalid
}

enum AdminRowDidSelect: Equatable {
    case Push(UIViewController), Present(UIViewController), Popover(UIViewController, CGSize), Alert(String, String, [String]), Reload, None
}

func ==(first: AdminRowDidSelect, second: AdminRowDidSelect) -> Bool {
    switch (first, second) {
    case (.Push(let vc), .Push(let vc2)) where vc == vc2: return true
    case (.Present(let vc), .Present(let vc2)) where vc == vc2: return true
    case (.Popover(let vc, let size), .Popover(let vc2, let size2)) where vc == vc2 && size == size2: return true
    case (.Alert(let title, let message, let values), .Alert(let title2, let message2, let values2)) where title == title2 && message == message2 && values == values2: return true
    case (.None, .None): return true
    default: return false
    }
}