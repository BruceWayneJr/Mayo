//
//  Printable.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//
// Base protocol which if implemented, can get a human readable string

import Foundation

protocol Printable {
    var description: String { get }
}