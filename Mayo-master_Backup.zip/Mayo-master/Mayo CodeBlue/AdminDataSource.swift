//
//  AdminDataSource.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 8/29/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class AdminDataSource {
    
    var repData: AdminRepresentationType!
    
    func numberOfSections() -> Int {
        return repData.admin_numberOfSections()
    }

    func numberOfRows(sectionIndex sectionIndex: Int) -> Int {
        return repData.admin_numberOfRowsForSection(sectionIndex)
    }
    
    func cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        return repData.admin_cellTypeForIndexPath(indexPath)
    }
    
    func heightForHeader(sectionIndex sectionIndex: Int) -> CGFloat {
        if titleForSection(sectionIndex) == "" {
            return 16.0
        } else {
            return 40
        }
    }
    
    func titleForSection(sectionIndex: Int) -> String {
        return repData.admin_sectionName(sectionIndex: sectionIndex)
    }
    
    func titleForFooter(sectionIndex sectionIndex: Int) -> String {
        return repData.admin_sectionFooter(sectionIndex: sectionIndex)
    }
    
    func didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        return repData.admin_didSelectRowAtIndexPath(indexPath)
    }
    
    func moveableSections() -> [Int] {
        return repData.admin_moveableSections()
    }
    
    func canMoveRowAtIndexPath(indexPath: NSIndexPath) -> Bool {
        return moveableSections().contains(indexPath.section)
    }
    
    func movedData(from from: Int, to: Int) {
        repData.admin_movedData(from: from, to: to)
    }
    
    func deleteData(rowIndex rowIndex: Int) {
        repData.admin_deletedRow(rowIndex)
    }
}