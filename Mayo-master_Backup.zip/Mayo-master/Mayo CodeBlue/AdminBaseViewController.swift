//
//  AdminBaseViewController.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 8/29/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol AdminBaseViewControllerDelegate {
    func didUpdateForms()
}

class AdminBaseViewController: UIViewController {
    
    var delegate: AdminBaseViewControllerDelegate?

    @IBOutlet weak var doneButton: Button!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    private func updateAndDismiss() {
        Mayo.newCode()
        delegate?.didUpdateForms()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func doneButtonPressed(sender: Button) {
        if Mayo.sharedInstance.form.admin_representationState() == .Valid {
            let newData = Mayo.sharedInstance.form.toJSON()
            File.writeNewForm(newData)
            
            updateAndDismiss()
        } else {
            let alertVC = UIAlertController(title: "Error", message: "There are one or more formatting errors. Please check them before saving", preferredStyle: .Alert)
            let okAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alertVC.addAction(okAction)
            presentViewController(alertVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func restoreDefaultButtonPressed(sender: Button) {
        let alertVC = UIAlertController(title: "Confirm", message: "Are you sure you want to restore forms to default?", preferredStyle: .Alert)
        let okAction = UIAlertAction(title: "Ok", style: .Default) { (_) -> Void in
            File.writeNewForm(File.readDefaultJSON())
            self.updateAndDismiss()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        alertVC.addAction(okAction)
        alertVC.addAction(cancelAction)
        presentViewController(alertVC, animated: true, completion: nil)
    }
    
    @IBAction func cancelButtonPressed(sender: Button) {
        updateAndDismiss()
    }
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "tableVC" {
            if let adminTableVC = (segue.destinationViewController as? UINavigationController)?.viewControllers.first as? AdminTableViewController {
                adminTableVC.setRepData(Mayo.sharedInstance.form)
            }
        }
    }

}
