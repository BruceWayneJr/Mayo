//
//  ItemFieldCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/26/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class ItemFieldCell: UICollectionViewCell {
    
    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var rightLabel: UILabel!
    @IBOutlet weak var rightLabelWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var textFieldRightPadding: NSLayoutConstraint!
    @IBOutlet weak var leftLabelWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var textFieldLeftPadding: NSLayoutConstraint!
    @IBOutlet weak var signView: SignatureView!

    var signature: UIImage?
    
    private var item: Item!
    private var collectionView: UICollectionView!
    private var numpadPopover: UIPopoverController!
    var delegate: CellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        signView.delegate = self
        signView.layer.borderWidth = 0.5
        
        backgroundColor = UIColor.whiteColor()
        layer.cornerRadius = 3
    }
    
    func setItemData(itemData: Item, collectionView: UICollectionView) {
        item = itemData
        self.collectionView = collectionView
        
        let rightText = itemData.detail
        let leftText = itemData.name
        
        leftLabel.text = leftText
        rightLabel.text = rightText
        
        if leftText == "" && rightText == "" {
            textField.textAlignment = .Left
        } else {
            textField.textAlignment = .Right
        }
        
        textField.text = item.stringValue
        textField.returnKeyType = .Done
        textField.placeholder = itemData.placeholder
        textField.delegate = self
        textField.addTarget(self, action: "textFieldDidChange:", forControlEvents: UIControlEvents.EditingChanged)
    }
}

extension ItemFieldCell: UITextFieldDelegate {
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        if item.type == .Text {
            return true
        } else if item.type == .Numeric {
            collectionView.endEditing(true)
            
            let numpad = NumPadViewController(nibName: "NumPadViewController", bundle: nil)
            numpad.number = textField.text!
            numpad.delegate = self
            
            numpadPopover = UIPopoverController(contentViewController: numpad)
            numpadPopover.popoverContentSize = CGSize(width: 212, height: 376)
            let f = collectionView.convertRect(frame, toView: collectionView)
            numpadPopover.presentPopoverFromRect(f, inView: collectionView, permittedArrowDirections: .Any, animated: true)
            
            return false
        }
        
        return false
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        item.stringValue = textField.text!
        if let log = item.getLog() {
            delegate?.newLog(log)
        }
        
        if !item.keep {
            textField.text = ""
        }
    }
    
    func textFieldDidChange(textField: UITextField) {
        item.stringValue = textField.text!
    }
}

extension ItemFieldCell: NumPadDelegate {
    func numPadDidEndEditing() {
        if let log = item.getLog() {
            delegate?.newLog(log)
        }
        
        if !item.keep {
             textField.text = ""
        }
        
        numpadPopover.dismissPopoverAnimated(true)
    }
    
    func numPadDidChange(number: String) {
        textField.text = number
        item.stringValue = number
    }
}

extension ItemFieldCell: SignatureViewDelegate {
    func didBeginDrawing() {
        collectionView?.scrollEnabled = false
        collectionView?.userInteractionEnabled = false
    }
    
    func didEndDrawing(image: UIImage?) {
        signature = image!
        
        collectionView?.scrollEnabled = true
        collectionView?.userInteractionEnabled = true
    }
    
    func clearedDrawing() {
        signature = nil
    }
}
