//
//  CellDelegate.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/9/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation

protocol CellDelegate {
    func newLog(message: String)
    func newLog(log: EventLog)
}