//
//  String+Height.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

extension String {
    func sizeToFit(maxSize: CGSize, font: UIFont) -> CGSize {
        return (self as NSString).boundingRectWithSize(maxSize, options: [NSStringDrawingOptions.UsesLineFragmentOrigin, NSStringDrawingOptions.UsesFontLeading], attributes: [NSFontAttributeName: font], context: nil).size
    }
}