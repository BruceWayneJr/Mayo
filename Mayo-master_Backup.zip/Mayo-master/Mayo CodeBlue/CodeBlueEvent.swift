//
//  CodeBlueEvent.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 6/25/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import Foundation

protocol CodeBlueEvent {
    func logEvent(event: String)
}
