//
//  BaseViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var alertLabel: UILabel!
    @IBOutlet weak var moreLabel: UILabel!
    
    private var alertMessages = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBarHidden = true
        
        alertView.alpha = 0
        alertView.backgroundColor = UIColor.backgroundBrightRed()
        alertLabel.textColor = UIColor.whiteColor()
        moreLabel.textColor = UIColor.whiteColor()
        moreLabel.alpha = 0
        
        dismissButton.backgroundColor = UIColor.whiteColor()
        dismissButton.setTitleColor(UIColor.backgroundBrightRed(), forState: .Normal)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "alert:", name: "EventAlert", object: nil)
    }
    
    internal func alert(notification: NSNotification) {
        if let message = notification.userInfo!["message"] as? String {
            newAlert(message)
        }
    }

    private func newAlert(message: String) {
        alertMessages.append(message.uppercaseString)
        
        if alertMessages.count == 1 {
            toggleAlertView(show: true)
        }
        
        toggleMoreLabel()
    }
    
    private func toggleMoreLabel() {
        let count = alertMessages.count - 1
        
        UIView.transitionWithView(moreLabel, duration: 0.33, options: UIViewAnimationOptions.TransitionCrossDissolve, animations: { () -> Void in
            self.moreLabel.alpha = count == 0 ? 0 : 1
            self.moreLabel.text = "and \(count) more"
        }) { (_) -> Void in
                
        }
    }
    
    private func toggleAlertView(show show: Bool) {
        alertLabel.text = show ? alertMessages.first : ""
        
        UIView.transitionWithView(alertView, duration: 0.33, options: .TransitionCrossDissolve, animations: { () -> Void in
            self.alertView.alpha = show ? 1 : 0
        }) { (_) -> Void in
                
        }
    }
    
    private func transitionLabel() {
        UIView.transitionWithView(alertLabel, duration: 0.33, options: .TransitionCrossDissolve, animations: { () -> Void in
            self.alertLabel.text = self.alertMessages.first
        }) { (_) -> Void in
                
        }
    }
    
    @IBAction func dismissButtonPressed(sender: AnyObject) {
        alertMessages = Array(alertMessages.dropFirst())
        
        if alertMessages.count > 0 {
            transitionLabel()
        } else {
            toggleAlertView(show: false)
        }
        
        toggleMoreLabel()
    }
}
