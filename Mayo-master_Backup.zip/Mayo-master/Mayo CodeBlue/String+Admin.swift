//
//  String+Admin.swift
//  Mayo Code Blue
//
//  Created by Harsh Damania on 9/23/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class CustomString {
    private var value = ""
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    lazy var updateValue: StringClosure = {
        self.value = $0
    }
    
    required convenience init() {
        self.init()
        self.value = ""
    }
    
    required init(value: String) {
        self.value = value
    }
    
    typealias ExtendedGraphemeClusterLiteralType = String
    typealias UnicodeScalarLiteralType = String
    
    required convenience init(stringLiteral value: String) {
        self.init(value: value)
    }
    
    required convenience init(extendedGraphemeClusterLiteral value: ExtendedGraphemeClusterLiteralType) {
        self.init(value: value)
    }
    
    required convenience init(unicodeScalarLiteral value: UnicodeScalarLiteralType) {
        self.init(value: value)
    }
}

extension CustomString: StringLiteralConvertible {
    
}

extension CustomString: CustomStringConvertible {
    var description: String {
        return value
    }
}

extension CustomString: AdminRepresentationType {
    
    
    func admin_numberOfSections() -> Int {

        return 1
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        return 1
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        return .Field(value, "", updateValue)
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return []
    }
    
    func admin_movedData(from from: Int, to: Int) {
        
    }
    
    func admin_deletedRow(rowIndex: Int) {
        
    }
    
    func admin_representationState() -> RepresentationState {
        return value == "" ? .Invalid : .Valid
    }
}






