//
//  DataSource.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

struct EventDataSource {
    let event: Event
    var sectionItemYs: [CGFloat]
    var headerYs: [CGFloat]
    
    init(event: Event) {
        self.event = event
        sectionItemYs = [CGFloat](count: event.sections.count, repeatedValue: -1)
        headerYs = [CGFloat](count: event.sections.count, repeatedValue: -1)
    }
    
    func numberOfSections() -> Int {
        return event.sections.count
    }
    
    func numberOfItemsInSection(section: Int) -> Int {
        return sectionAtIndex(section).items.count
    }
    
    func sectionAtIndex(index: Int) -> Section {
        return event.sections[index]
    }
    
    func itemForSection(sectionIndex: Int, atIndex index:Int) -> Item {
        return sectionAtIndex(sectionIndex).items[index]
    }
    
    func numberPerRow(indexPath: NSIndexPath) -> CGFloat {
        let section = sectionAtIndex(indexPath.section)
        
        switch section.view {
        case .Collection:
            let maxInRow: CGFloat = 6
            var numberPerRow = CGFloat(section.numberPerRow) > maxInRow ? maxInRow : CGFloat(section.numberPerRow)
            
            if CGFloat(section.items.count) > numberPerRow {
                let modValue = section.items.count % Int(numberPerRow)
                if indexPath.item >= (section.items.count - modValue) {
                    numberPerRow = CGFloat(modValue)
                }
            }
            
            return numberPerRow
        case .List, .Comment, .Signature:
            return 1
        }
    }
    
    func sizeForItemAtIndexPath(indexPath: NSIndexPath, collectionView: UICollectionView) -> CGSize {
        let viewWidth = CGRectGetWidth(collectionView.frame)
        var itemWidth: CGFloat
        let section = sectionAtIndex(indexPath.section)
        
        switch section.view {
        case .Collection:
            let numPerRow = numberPerRow(indexPath)
            itemWidth = floor((viewWidth - (numPerRow+1)*8)/numPerRow)
        case .Comment, .List, .Signature:
            itemWidth = viewWidth - 16
        }
        
        return CGSize(width: itemWidth, height: section.view.itemHeight)
    }
    
    func contentHeight() -> CGFloat {
        var height: CGFloat = 0
        for section in event.sections {
            let numRows = ceil(CGFloat(section.items.count) / CGFloat(section.numberPerRow))
            height += ((numRows-1)*8 + numRows*section.view.itemHeight)
            //account for section headers too
            height += 16 // 8 top and bottom
            height += section.name != "" ? 40 : 0 // 40 for section
        }
        
        return height
    }
    
    mutating func sectionHeaderYsForSection(index: Int) -> CGFloat {
        if headerYs[index] != -1 {
            return headerYs[index]
        }
        
        if index == 0 {
            headerYs[0] = 0
            return 0
        }
        
        let previousHeaderY = sectionHeaderYsForSection(index-1)
        let previousSection = sectionAtIndex(index - 1)
        let previousNumRows = ceil(CGFloat(previousSection.items.count) / CGFloat(previousSection.numberPerRow))
        var currMinY = previousHeaderY + (previousNumRows * previousSection.view.itemHeight) + ((previousNumRows+1)*8)
        currMinY += previousSection.name != "" ? 40 : 0
        headerYs[index] = currMinY
        
        return currMinY
    }
    
    
    mutating func sectionItemsMinYForIndex(sectionIndex: Int) -> CGFloat {
        if sectionItemYs[sectionIndex] != -1 {
            return sectionItemYs[sectionIndex]
        }
        
        let headerY = sectionHeaderYsForSection(sectionIndex)
        let section = sectionAtIndex(sectionIndex)
        let Y: CGFloat = section.name != "" ? 48 : 8
        return headerY + Y
    }
}
