//
//  NumPadViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/9/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol NumPadDelegate {
    func numPadDidChange(number: String)
    func numPadDidEndEditing()
}

class NumPadViewController: UIViewController {
    
    var number: String = "" {
        didSet {
            delegate?.numPadDidChange(number)
        }
    }
    var delegate: NumPadDelegate?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.backgroundDarkerGray()
    }
    
    @IBAction func numPadButtonTapped(sender: Button) {
        number += sender.titleLabel!.text!
    }

    @IBAction func clearTapped(sender: Button) {
        if number.characters.count > 0 {
            number.removeAtIndex(number.endIndex.predecessor())
        }
    }
    
    @IBAction func doneTapped(sender: Button) {
        delegate?.numPadDidEndEditing()
    }
}
