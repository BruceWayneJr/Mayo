//
//  ItemCommentCell.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/12/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class ItemCommentCell: UICollectionViewCell {
    
    @IBOutlet weak var commentTextView: UITextView!
    @IBOutlet weak var activitiesButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    private var popover: UIPopoverController?
    private var item: Item?
    private var collectionView: UICollectionView?
    var delegate: CellDelegate?
    
    override func awakeFromNib() {
        backgroundColor = UIColor.whiteColor()
        layer.cornerRadius = 3
        
        commentTextView.textContainerInset = UIEdgeInsetsZero
    }
    
    func setItemData(item: Item, collectionView: UICollectionView) {
        self.item = item
        self.collectionView = collectionView
        
        if let predefinedValues = item.predefinedValues {
            activitiesButton.setTitle(predefinedValues.name.uppercaseString, forState: .Normal)
            activitiesButton.hidden = false
        } else {
            activitiesButton.hidden = true
        }
        
        commentTextView.text = item.stringValue
        commentTextView.delegate = self
    }
    
    @IBAction func saveButtonPressed(sender: Button) {
        if let log = item?.getLog() {
            delegate?.newLog(log)
        }
        
        if !item!.keep {
            commentTextView.text = ""
        }
    }
    
    @IBAction func activitiesButtonPressed(sender: Button) {
        collectionView?.endEditing(true)
        
        let valuesVC = PredefinedValuesTableViewController(style: .Plain, values: item!.predefinedValues!.values.map { $0.description } )
        popover = UIPopoverController(contentViewController: valuesVC)
        valuesVC.delegate = self
        
        var height = item!.predefinedValues!.values.count * 44
        height = height > 320 ? 320 : height
        popover?.popoverContentSize = CGSize(width: 250, height: height)
        
        let rect = collectionView!.convertRect(activitiesButton.frame, fromView: contentView)
        popover?.presentPopoverFromRect(rect, inView: collectionView!, permittedArrowDirections: .Any, animated: true)
    }
}

extension ItemCommentCell: PredefinedValuesTableVCDelegate {
    func didSelectValue(value: String) {
        commentTextView.text = commentTextView.text + value
        item?.stringValue = commentTextView.text
        
        popover?.dismissPopoverAnimated(true)
    }
}

extension ItemCommentCell: UITextViewDelegate {
    func textViewDidChange(textView: UITextView) {
        item?.stringValue = textView.text
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        item?.stringValue = textView.text
    }
}
