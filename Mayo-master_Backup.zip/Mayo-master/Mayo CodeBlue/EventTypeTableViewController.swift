//
//  EventTypeTableViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/10/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class EventTypeTableViewController: UITableViewController {
    
    var data = Mayo.sharedInstance.code.events
    var delegate: MasterViewDelegate?
    @IBOutlet weak var tableHeaderLabel: UILabel!
    
    override func viewDidLoad() {
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 64
        
        tableView.backgroundColor = UIColor.backgroundLightGray()
        
        tableView.tableFooterView = UIView()
        tableView.separatorStyle = .None
        
        tableHeaderLabel.text = Mayo.sharedInstance.code.name.uppercaseString
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "newCodeInitiated", name: "NewCode", object: nil)
    }
    
    override func viewWillAppear(animated: Bool) {
        tableView.selectRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0), animated: true, scrollPosition: .None)
    }
    
    func newCodeInitiated() {
        data = Mayo.sharedInstance.code.events
        tableView.reloadData()
        
        tableView.selectRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0), animated: true, scrollPosition: .Top)
        delegate?.updateSelectedIndex(0)
    }
    
    func setSelectedIndex(index: Int) {
        if index < data.count {
            tableView.selectRowAtIndexPath(NSIndexPath(forRow: index, inSection: 0), animated: true, scrollPosition: .None)
        }
    }
    
    func updateData(data: [Event]) {
        self.data = data
        tableView.reloadData()
    }

    @IBAction func editButtonPressed(sender: AnyObject) {
        let adminVC = storyboard?.instantiateViewControllerWithIdentifier("AdminBaseViewController") as! AdminBaseViewController
        adminVC.modalPresentationStyle = .OverFullScreen
        adminVC.modalTransitionStyle = .CrossDissolve
        presentViewController(adminVC, animated: true, completion: nil)
    }
}

// data source
extension EventTypeTableViewController {
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("EventTypeCell", forIndexPath: indexPath) as! EventTypeCell
        cell.setType(data[indexPath.row].name)
        return cell
    }
}

extension EventTypeTableViewController {
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        delegate?.updateSelectedIndex(indexPath.row)
    }
}
