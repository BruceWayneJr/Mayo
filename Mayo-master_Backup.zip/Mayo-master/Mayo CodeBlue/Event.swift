//
//  Event.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 7/18/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Event: Decodable {
    var adminTableDelegate: AdminTableViewControllerDelegate?
    
    var name = ""
    var sections = [Section]()
    
    required init() {
        name = ""
        sections = [Section]()
    }
    
    lazy var updateName: StringClosure = {
        self.name = $0 == "" ? self.name : $0
    }
    
    required convenience init(data: JSON) {
        self.init()
        
        guard let name = data["name"] as? String else {
            // return error
            return
        }
        
        guard let sections = data["sections"] as? Array<JSON> else {
            // return error
            return
        }
        
        self.name = name
        for sec in sections {
            let dataSection = Section(data: sec)
            self.sections.append(dataSection)
        }
    }
    
    func toJSON() -> JSON {
        return [
            "name": name,
            "sections": sections.map { $0.toJSON() }
        ]
    }
}

extension Event: AdminRepresentationType {
    
    private var nameSectionIndex: Int { get { return 0 } }
    private var sectionsSectionIndex: Int { get { return 1 } }
    private var newSectionIndex: Int { get { return 2 } }
    
    func admin_numberOfSections() -> Int {
        return 3
    }
    
    func admin_numberOfRowsForSection(sectionIndex: Int) -> Int {
        switch sectionIndex {
        case nameSectionIndex: return 1
        case sectionsSectionIndex: return sections.count
        case newSectionIndex: return 1
        default: return 0
        }
    }
    
    func admin_cellTypeForIndexPath(indexPath: NSIndexPath) -> CellType {
        if indexPath.section == nameSectionIndex {
            return .Field(name, "Name", updateName)
        } else if indexPath.section == sectionsSectionIndex {
            let currentSection = sections[indexPath.row]
            return .Standard(currentSection.name == "" ? "No Section Name" : currentSection.name, "Section", currentSection.admin_representationState())
        } else {
            return .Standard("Add new Section", "", .Valid)
        }
    }
    
    func admin_sectionName(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex != sectionsSectionIndex {
            return ""
        } else {
            return "\(sections.count) section(s)"
        }
    }
    
    func admin_sectionFooter(sectionIndex sectionIndex: Int) -> String {
        if sectionIndex == 0 {
            return "• Name for Event is required"
        } else if sectionIndex == 2 {
            return "• There has to be at least 1 Section for a Event"
        }
        
        return ""
    }
    
    func admin_didSelectRowAtIndexPath(indexPath: NSIndexPath) -> AdminRowDidSelect {
        if indexPath.section == 1 {
            let section = sections[indexPath.row]
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(section)
            section.adminTableDelegate = pushVC
            return .Push(pushVC)
        } else if indexPath.section == 2 {
            let newSection = Section()
            sections.append(newSection)
            let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AdminTableViewController") as! AdminTableViewController
            pushVC.setRepData(newSection)
            newSection.adminTableDelegate = pushVC
            return .Push(pushVC)
        }
        
        return .None
    }
    
    func admin_moveableSections() -> [Int] {
        return [sectionsSectionIndex]
    }
    
    func admin_movedData(from from: Int, to: Int) {
        let movedData = sections.removeAtIndex(from)
        sections.insert(movedData, atIndex: to)
    }
    
    func admin_deletedRow(rowIndex: Int) {
        if rowIndex >= 0 && rowIndex < sections.count {
            sections.removeAtIndex(rowIndex)
        }
    }
    
    func admin_representationState() -> RepresentationState {
        if name != "" {
            if sections.count > 0 {
                for section in sections {
                    if section.admin_representationState() == .Invalid {
                        return .Invalid
                    }
                }
                
                return .Valid
            }
        }
        
        
        return .Invalid
    }
}