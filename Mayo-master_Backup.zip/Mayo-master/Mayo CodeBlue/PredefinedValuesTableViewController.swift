//
//  PredefinedValuesTableViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/12/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol PredefinedValuesTableVCDelegate {
    func didSelectValue(value: String)
}

class PredefinedValuesTableViewController: UITableViewController {
    
    private var values = [String]()
    var delegate: PredefinedValuesTableVCDelegate?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    init(style: UITableViewStyle, values: [String]) {
        super.init(style: style)
        
        self.values = values
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.values = [String]()
    }
    
    override func viewDidLoad() {
        tableView.tableFooterView = UIView()
        tableView.registerClass(UITableViewCell.classForCoder(), forCellReuseIdentifier: "cell")
        
        tableView.dataSource = self
    }

}

// data source
extension PredefinedValuesTableViewController {
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return values.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        cell.layoutMargins = UIEdgeInsetsZero
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsetsZero

        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = values[indexPath.row]
        cell.textLabel?.font = UIFont(name: "Open Sans", size: 15)
        
        return cell
    }
}

extension PredefinedValuesTableViewController {
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        delegate?.didSelectValue(values[indexPath.row])
    }
}
