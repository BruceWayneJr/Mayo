//
//  Button.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/9/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class Button: UIButton {

    override func awakeFromNib() {
        backgroundColor = UIColor.whiteColor()
        setTitleColor(UIColor.blackColor(), forState: .Normal)
        setTitleColor(UIColor.whiteColor(), forState: .Highlighted)
        
        layer.cornerRadius = 3
    }
    
    override var highlighted: Bool {
        didSet {
            backgroundColor = highlighted ? UIColor.backgroundBrightRed() : UIColor.whiteColor()
        }
    }

}
