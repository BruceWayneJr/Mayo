//
//  SignatureView.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 8/13/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

protocol SignatureViewDelegate {
    func didBeginDrawing()
    func didEndDrawing(image: UIImage?)
    func clearedDrawing()
}

class SignatureView: UIView {
    
    private var path: UIBezierPath
    private var curveCenter = 0
    private var points = [CGPoint](count: 5, repeatedValue: CGPointZero)
    private var image: UIImage?
    
    var delegate: SignatureViewDelegate?
    
    private let backColor = UIColor(red: 250/255.0, green: 250/255.0, blue: 250/255.0, alpha: 1.0)
    
    private var clearButton: UIButton!

    override func drawRect(rect: CGRect) {
        image?.drawInRect(rect)
        path.stroke()
    }

    required init?(coder aDecoder: NSCoder) {
        path = UIBezierPath()
        path.lineWidth = 1.5
        
        super.init(coder: aDecoder)
        multipleTouchEnabled = false
        backgroundColor = backColor
        
        addClearButton()
    }
    
    override init(frame: CGRect) {
        path = UIBezierPath()
        path.lineWidth = 1.5
        
        super.init(frame: frame)
        multipleTouchEnabled = false
        backgroundColor = backColor
        
        addClearButton()
    }
    
    func setImage(image: UIImage) {
        self.image = image
        setNeedsDisplay()
    }
    
    func addClearButton() {
        let f = CGRect(x: 8, y: 8, width: 32, height: 22)
        clearButton = UIButton(frame: f)
        clearButton.setTitle("clear", forState: .Normal)
        clearButton.titleLabel?.font = UIFont(name: "Open Sans", size: 14)
        clearButton.setTitleColor(UIColor.blackColor(), forState: .Normal)
        clearButton.backgroundColor = UIColor.clearColor()
        clearButton.tintColor = UIColor.backgroundBrightRed()
        
        clearButton.addTarget(self, action: "clearButtonPressed", forControlEvents: .TouchUpInside)
        
        self.addSubview(clearButton)
    }
    
    func clearButtonPressed() {
        image = nil
        path = UIBezierPath()
        path.lineWidth = 1.5
        
        setNeedsDisplay()
        delegate?.clearedDrawing()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        delegate?.didBeginDrawing()
        
        curveCenter = 0
        let touch = touches.first!
        points[0] = touch.locationInView(self)
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let touch = touches.first!
        let p = touch.locationInView(self)
        curveCenter++
        points[curveCenter] = p
        if curveCenter == 4 {
            points[3] = CGPoint(x: (points[2].x + points[4].x)/2.0, y: (points[2].y + points[4].y)/2.0)
            path.moveToPoint(points[0])
            path.addCurveToPoint(points[3], controlPoint1: points[1], controlPoint2: points[2])
            
            setNeedsDisplay()
            points[0] = points[3]
            points[1] = points[4]
            curveCenter = 1
        }
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        drawBitmap()
        setNeedsDisplay()
        path.removeAllPoints()
        curveCenter = 0
        
        delegate?.didEndDrawing(image)
    }
    
    override func touchesCancelled(touches: Set<UITouch>?, withEvent event: UIEvent?) {
        touchesEnded(touches!, withEvent: event)
    }
    
    
    func drawBitmap() {
        UIGraphicsBeginImageContextWithOptions(bounds.size, true, 0)
        
        if image == nil {
            let newPath = UIBezierPath(rect: bounds)
            backColor.setFill()
            newPath.fill()
        }
        
        image?.drawAtPoint(CGPointZero)
        UIColor.blackColor().setStroke()
        path.stroke()
        image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }

}
