//
//  DetailViewController.swift
//  Mayo CodeBlue
//
//  Created by Harsh Damania on 6/25/15.
//  Copyright © 2015 Harsh Damania. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    var collectionVC: CollectionViewController?

    var selectedIndex = 0 {
        didSet {
            collectionVC?.selectedIndex = selectedIndex
        }
    }

    var detailItem: AnyObject? {
        didSet {
            // Update the view.
            self.configureView()
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
        
        view.backgroundColor = UIColor.backgroundLightGray()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "CollectionView" {
            let collectionVC = segue.destinationViewController as! CollectionViewController
            self.collectionVC = collectionVC
            collectionVC.selectedIndex = selectedIndex
        }
    }
}

